<?php

	defined('BASEPATH') OR exit('Tidak ada akses halaman yang diizinkan');

	$lang['ext_invalid_login_crendentials'] = 'Username atau Password yang Anda masukkan salah.';

	$lang['ext_non_active_user'] = 'Silakan periksa LINK aktivasi yang telah kami kirimkan kepada Anda melalui email.';

	$lang['ext_blocked_user'] = 'Akun ini telah dibanned.';

	$lang['ext_reset_pwd_message'] = "










    <table>
	<tbody>
		<tr>
			<td>

			<p style='text-align: center;'><br />
			<strong>
			    
			
<p style='text-align: center;'><span style='color:#000000;'><strong><span style='font-size:30px;'><span style='font-family:arial,helvetica,sans-serif;'>Hai Sahabat Netizen</p></p><br />			


			<p style='text-align: center;'><strong><span style='font-size:18px;'><span style='font-family:arial,helvetica,sans-serif;'>TERIMA KASIH TELAH MEMINTA PASSWORD BARU</span></span></strong></p><br>
			
			<p style='text-align: center;'><strong><span style='font-size:12px;'><span style='font-family:arial,helvetica,sans-serif;'>Anda telah meminta untuk mengubah password Anda. Jika ini adalah Anda,</br> Silakan klik LINK dibawah ini mengonfirmasi bahwa ini adalah Anda<center><b><font size='3' color='cb0c4b'>Jika bukan Anda yang meminta,<br> mohon abaikan pesan ini.</font></b></center></span></span></strong></p><br>
			
			<div style='background-color: Moccasin; border: 2px #E60045 dotted; padding: 10px; text-align: left;'>			
					                            			<p style='text-align: center;'><span style='color:#660099;'><strong><span style='font-size:20px;'><span style='font-family:arial,helvetica,sans-serif;'><font color='#F80046'><a href=\"[CONFIRM_URL]\" [CSS_STYLE]>GANTI PASSWORD SAYA</a></font><br>
					                            			
					                            			<span style='color:#000000;'><strong><span style='font-size:15px;'><span style='font-family:arial,helvetica,sans-serif;'>ATAU KLIK LINK DIBAWAH INI</font><br>
					                            			
					                            			<span style='color:#000000;'><strong><span style='font-size:13px;'><span style='font-family:arial,helvetica,sans-serif;'><a href=\"[CONFIRM_URL]\">[CONFIRM_URL]</a></p></p></div><br />


</strong></p>


			<p style='text-align: center;'><strong><span style='font-size:15px;'><span style='font-family:arial,helvetica,sans-serif;'>SEMUA DATA AKUN ANDA, TERSIMPAN<br /> DENGAN AMAN OLEH SISTEM KAMI.</span></span></strong></p>

			<p style='text-align: center;'><span style='color:#ff0033;'><strong><span style='font-size:11px;'><span style='font-family:arial,helvetica,sans-serif;'>LAPORKAN JIKA AKUN ANDA TERKENA HACK:</span></span></strong></span></p>

			<p style='text-align: center;'><span style='font-size:15px;'><span style='font-family:arial,helvetica,sans-serif;'><a href='mailto:mediatizen.com@gmail.com?Subjek=Hallo%20Mediatizen' target='_top'>mediatizen.com@gmail.com</a></span></span></p>

			<p style='text-align: center;'><strong><span style='font-size:17px;'><span style='font-family:arial,helvetica,sans-serif;'>PT. MEDIATIZEN PRODUCTION</strong></p>
			
			<p style='text-align: center;'><strong><span style='font-size:10px;'><span style='font-family:arial,helvetica,sans-serif;'>© Copyright 2020 - All Rights Reserved [SITE_NAME].</strong></p>			
			</td>
		</tr>

	</tbody>
</table>

    <table>
	<tbody>
	
	
<center><td style='color: #ffffff; padding: 15px 0; font-size: 30px; border-top:5px solid #52bfd3;' colspan='2' align='center' bgcolor='#ffffff'>© Copyright 2020 - All Rights Reserved [SITE_NAME].</div>
	
	
	<div style='background-color: lightyellow; border: 2px dotted rgb(230, 0, 69); padding: 10px; text-align: center;'><span style='font-size:11px;'><center><span style='color:#000000;'>Pesan ini dikirim sesuai alamat email yang Anda daftarkan.</center> <center> </center>
<center><span style='color:#000000;'>Jangan membalas email dari kami, karena email ini tidak kami pantau.</center>
<center><span style='color:#000000;'>Jika Anda merasa tidak pernah mendaftarkan alamat email ini</center>
<center><span style='color:#000000;'>sebagai pendaftaran, silahkan lapor: lapor@mediatizen.com</span></span></span></div></center>	
	

	</tbody>
</table>












	";

	$lang['ext_reset_pwd_confirmation'] = 'Email dengan instruksi untuk mengubah password telah dikirim ke akun email Anda.';

	$lang['ext_reset_pwd_done'] = 'Password Anda telah diubah, kini Anda dapat masuk dengan password baru Anda';

	$lang['ext_account_activation_message'] = "







    <table>
	<tbody>
		<tr>
			<td>

			<p style='text-align: center;'><br />
			<strong>
			    
			
<p style='text-align: center;'><span style='color:#000000;'><strong><span style='font-size:30px;'><span style='font-family:arial,helvetica,sans-serif;'>Hai Sahabat Netizen</p></p><br />			


			<p style='text-align: center;'><strong><span style='font-size:20px;'><span style='font-family:arial,helvetica,sans-serif;'>TERIMA KASIH TELAH BERGABUNG DI MEDIATIZEN</span></span></strong></p><br>
			
			<p style='text-align: center;'><strong><span style='font-size:18px;'><span style='font-family:arial,helvetica,sans-serif;'>Silakan, klik tombol di bawah ini untuk mengaktifkan akun Anda.</span></span></strong></p><br>
			
			<div style='background-color: Moccasin; border: 2px #E60045 dotted; padding: 10px; text-align: left;'>			
					                            			<p style='text-align: center;'><span style='color:#660099;'><strong><span style='font-size:30px;'><span style='font-family:arial,helvetica,sans-serif;'><font color='#F80046'><a href=\"[ACTIV_LINK]\" [CSS_STYLE]>AKTIFKAN AKUN SAYA</a><br>
					                            			
					                            			<span style='color:#000000;'><strong><span style='font-size:15px;'><span style='font-family:arial,helvetica,sans-serif;'>ATAU KLIK LINK DIBAWAH INI</font><br>
					                            			
					                            			<span style='color:#000000;'><strong><span style='font-size:13px;'><span style='font-family:arial,helvetica,sans-serif;'>[ACTIV_LINK]</p></p></div><br />


</strong></p>


			<p style='text-align: center;'><strong><span style='font-size:15px;'><span style='font-family:arial,helvetica,sans-serif;'>SEMUA DATA AKUN ANDA, TERSIMPAN<br /> DENGAN AMAN OLEH SISTEM KAMI.</span></span></strong></p>

			<p style='text-align: center;'><span style='color:#ff0033;'><strong><span style='font-size:11px;'><span style='font-family:arial,helvetica,sans-serif;'>LAPORKAN JIKA AKUN ANDA TERKENA HACK:</span></span></strong></span></p>

			<p style='text-align: center;'><span style='font-size:15px;'><span style='font-family:arial,helvetica,sans-serif;'><a href='mailto:mediatizen.com@gmail.com?Subjek=Hallo%20Mediatizen' target='_top'>mediatizen.com@gmail.com</a></span></span></p>

			<p style='text-align: center;'><strong><span style='font-size:17px;'><span style='font-family:arial,helvetica,sans-serif;'>PT. MEDIATIZEN PRODUCTION</strong></p>
			
			<p style='text-align: center;'><strong><span style='font-size:10px;'><span style='font-family:arial,helvetica,sans-serif;'>© Copyright 2020 - All Rights Reserved [SITE_NAME].</strong></p>			
			</td>
		</tr>

	</tbody>
</table>

    <table>
	<tbody>
	
	
<center><td style='color: #ffffff; padding: 15px 0; font-size: 27px; border-top:5px solid #52bfd3;' colspan='2' align='center' bgcolor='#ffffff'>© Copyright 2020 - All Rights Reserved [SITE_NAME].</div>
	
	
	<div style='background-color: lightyellow; border: 2px dotted rgb(230, 0, 69); padding: 10px; text-align: center;'><span style='font-size:11px;'><center><span style='color:#000000;'>Pesan ini dikirim sesuai alamat email yang Anda daftarkan.</center> <center> </center>
<center><span style='color:#000000;'>Jangan membalas email dari kami, karena email ini tidak kami pantau.</center>
<center><span style='color:#000000;'>Jika Anda merasa tidak pernah mendaftarkan alamat email ini</center>
<center><span style='color:#000000;'>sebagai pendaftaran, silahkan lapor: lapor@mediatizen.com</span></span></span></div></center>	
	

	</tbody>
</table>








	";

	$lang['ext_account_activation_done'] = "Berhasil!<br>Kami mengirimi Anda email berisi link untuk mengaktifkan akun Anda";

	$lang['ext_unknown_error'] = 'Kesalahan yang tidak diketahui.';

	$lang['ext_form_error'] = 'Error!';

	$lang['ext_form_success'] = 'Selesai!';
